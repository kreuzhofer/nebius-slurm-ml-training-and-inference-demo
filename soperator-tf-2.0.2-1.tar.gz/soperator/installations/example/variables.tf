# region Cloud

variable "region" {
  description = "Region of the project."
  type        = string
  nullable    = false
}
resource "terraform_data" "check_region" {
  lifecycle {
    precondition {
      condition     = contains(module.resources.regions, var.region)
      error_message = "Unknown region '${var.region}'. See https://docs.nebius.com/overview/regions"
    }
  }
}

variable "iam_token" {
  description = "IAM token used for communicating with Nebius services."
  type        = string
  nullable    = false
  sensitive   = true
}

variable "iam_project_id" {
  description = "ID of the IAM project."
  type        = string
  nullable    = false

  validation {
    condition     = startswith(var.iam_project_id, "project-")
    error_message = "ID of the IAM project must start with `project-`."
  }
}
data "nebius_iam_v1_project" "this" {
  id = var.iam_project_id
}

variable "iam_tenant_id" {
  description = "ID of the IAM tenant."
  type        = string
  nullable    = false

  validation {
    condition     = startswith(var.iam_tenant_id, "tenant-")
    error_message = "ID of the IAM tenant must start with `tenant-`."
  }
}

data "nebius_iam_v1_tenant" "this" {
  id = var.iam_tenant_id
}

variable "o11y_iam_tenant_id" {
  description = "ID of the IAM tenant for O11y."
  type        = string
  nullable    = false

  validation {
    condition     = startswith(var.o11y_iam_tenant_id, "tenant-")
    error_message = "ID of the IAM tenant must start with `tenant-`."
  }
}

variable "o11y_profile" {
  description = "Profile for nebius CLI for public o11y."
  type        = string
  nullable    = false

  validation {
    condition = (
      (length(var.o11y_profile) >= 1 && var.public_o11y_enabled) ||
      !var.public_o11y_enabled
    )
    error_message = "O11y profile must be not empty if public o11y enabled is true."
  }
}

variable "production" {
  type    = bool
  default = true
}

variable "iam_merge_request_url" {
  type    = string
  default = ""

  validation {
    condition     = (var.production && length(var.iam_merge_request_url) > 0) || !var.production
    error_message = <<EOF
This variable must be set for PRODUCTION Soperator Pro clusters. Follow the installation guide and put IAM merge request URL here.

If you provision a NON-PRODUCTION cluster, set "production" variable to false.
    EOF
  }
}

variable "vpc_subnet_id" {
  description = "ID of VPC subnet."
  type        = string

  validation {
    condition     = startswith(var.vpc_subnet_id, "vpcsubnet-")
    error_message = "The ID of the VPC subnet must start with `vpcsubnet-`."
  }
}
data "nebius_vpc_v1_subnet" "this" {
  id = var.vpc_subnet_id
}

variable "slurm_login_public_ip" {
  description = "Public or private ip for login node load balancer"
  type        = bool
  default     = true
}

variable "tailscale_enabled" {
  description = "Whether to enable tailscale init container on login pod"
  type        = bool
  default     = false
}

variable "company_name" {
  description = "Name of the company. It is used for naming Slurm & K8s clusters."
  type        = string

  validation {
    condition = (
      length(var.company_name) >= 1 &&
      length(var.company_name) <= 32 &&
      length(regexall("^[a-z][a-z\\d\\-]*[a-z\\d]+$", var.company_name)) == 1
    )
    error_message = <<EOF
      The company name must:
      - be 1 to 32 characters long
      - start with a letter
      - end with a letter or digit
      - consist of letters, digits, or hyphens (-)
      - contain only lowercase letters
    EOF
  }
}

# endregion Cloud

# region Infrastructure

# region Storage

variable "controller_state_on_filestore" {
  description = "Whether to use Filestore for controller node boot disk (true = Filestore, false = PVC)."
  type        = bool
  default     = false
}

variable "filestore_controller_spool" {
  description = "Shared filesystem to be used on controller nodes."
  type = object({
    existing = optional(object({
      id = string
    }))
    spec = optional(object({
      size_gibibytes       = number
      block_size_kibibytes = number
    }))
  })
  nullable = false

  validation {
    condition = (
      (var.filestore_controller_spool.existing != null && var.filestore_controller_spool.spec == null) ||
      (var.filestore_controller_spool.existing == null && var.filestore_controller_spool.spec != null)
    )
    error_message = "One of `existing` or `spec` must be provided."
  }
}

variable "filestore_jail" {
  description = "Shared filesystem to be used on controller, worker, and login nodes."
  type = object({
    existing = optional(object({
      id = string
    }))
    spec = optional(object({
      size_gibibytes       = number
      block_size_kibibytes = number
    }))
  })
  nullable = false

  validation {
    condition = (
      (var.filestore_jail.existing != null && var.filestore_jail.spec == null) ||
      (var.filestore_jail.existing == null && var.filestore_jail.spec != null)
    )
    error_message = "One of `existing` or `spec` must be provided."
  }
}

data "nebius_compute_v1_filesystem" "existing_jail" {
  count = var.filestore_jail.existing != null ? 1 : 0

  id = var.filestore_jail.existing.id
}

locals {
  filestore_jail_calculated_size_gibibytes = (var.filestore_jail.existing != null ?
    data.nebius_compute_v1_filesystem.existing_jail[0].size_bytes / 1024 / 1024 / 1024 :
  var.filestore_jail.spec.size_gibibytes)
}

variable "allow_empty_jail_submounts" {
  description = "Flag for disabling validation for non-empty jail submounts."
  type        = bool
  default     = false
}

variable "filestore_jail_submounts" {
  description = "Shared filesystems to be mounted inside jail."
  type = list(object({
    name       = string
    mount_path = string
    existing = optional(object({
      id = string
    }))
    spec = optional(object({
      size_gibibytes       = number
      block_size_kibibytes = number
    }))
  }))
  default = []

  validation {
    condition = length([
      for sm in var.filestore_jail_submounts : true if
      (sm.existing != null && sm.spec == null) ||
      (sm.existing == null && sm.spec != null)
    ]) == length(var.filestore_jail_submounts)
    error_message = "All submounts must have one of `existing` or `spec` provided."
  }

  validation {
    condition     = var.allow_empty_jail_submounts || length(var.filestore_jail_submounts) >= 1
    error_message = "Creating clusters without jail submounts is not allowed."
  }
}

variable "node_local_jail_submounts" {
  description = "Node-local disks to be mounted inside jail on worker nodes."
  type = list(object({
    name            = string
    mount_path      = string
    size_gibibytes  = number
    disk_type       = string
    filesystem_type = string
  }))
  nullable = false
  default  = []

  validation {
    condition = alltrue([
      for sm in var.node_local_jail_submounts : (
        contains(
          [
            module.resources.disk_types.network_ssd,
            module.resources.disk_types.network_ssd_non_replicated,
            module.resources.disk_types.network_ssd_io_m3,
          ],
          sm.disk_type
        )
    )])
    error_message = "Disk type must be one of `NETWORK_SSD`, `NETWORK_SSD_NON_REPLICATED` or `NETWORK_SSD_IO_M3`. See https://docs.nebius.com/compute/storage/types#disks-types"
  }
  validation {
    condition = alltrue([
      for sm in var.node_local_jail_submounts : (
        contains(
          [
            module.resources.filesystem_types.ext4,
            module.resources.filesystem_types.xfs,
          ],
          sm.filesystem_type
        )
    )])
    error_message = "Filesystem type must be one of `ext4` or `xfs`."
  }
}

variable "node_local_image_disk" {
  description = "Whether to create extra NRD/IO M3 disks for storing Docker/Enroot images and container filesystems on each worker node."
  type = object({
    enabled = bool
    spec = optional(object({
      size_gibibytes  = number
      filesystem_type = string
      disk_type       = string
    }))
  })
  default = {
    enabled = false
  }

  validation {
    condition = (var.node_local_image_disk.enabled
      ? var.node_local_image_disk.spec != null
      : true
    )
    error_message = "Spec must be provided if enabled."
  }
  validation {
    condition = (var.node_local_image_disk.spec == null
      ? true
      : (contains(
        [
          module.resources.filesystem_types.ext4,
          module.resources.filesystem_types.xfs,
        ],
        var.node_local_image_disk.spec.filesystem_type
      ))
    )
    error_message = "Filesystem type must be one of `ext4` or `xfs`."
  }
  validation {
    condition = (var.node_local_image_disk.spec == null
      ? true
      : (contains(
        [
          module.resources.disk_types.network_ssd_non_replicated,
          module.resources.disk_types.network_ssd_io_m3,
        ],
        var.node_local_image_disk.spec.disk_type
      ))
    )
    error_message = "Local image disk type must be one of `NETWORK_SSD_NON_REPLICATED` or `NETWORK_SSD_IO_M3`. See https://docs.nebius.com/compute/storage/types#disks-types"
  }
}

variable "filestore_accounting" {
  description = "Shared filesystem to be used for accounting DB"
  type = object({
    existing = optional(object({
      id = string
    }))
    spec = optional(object({
      size_gibibytes       = number
      block_size_kibibytes = number
    }))
  })
  default  = null
  nullable = true

  validation {
    condition = (var.filestore_accounting != null
      ? (
        (var.filestore_accounting.existing != null && var.filestore_accounting.spec == null) ||
        (var.filestore_accounting.existing == null && var.filestore_accounting.spec != null)
      )
      : true
    )
    error_message = "One of `existing` or `spec` must be provided."
  }
}

# endregion Storage

# region nfs-server

variable "nfs" {
  type = object({
    enabled        = bool
    size_gibibytes = number
    mount_path     = optional(string, "/home")
    resource = object({
      platform = string
      preset   = string
    })
    public_ip = bool
  })
  default = {
    enabled        = false
    size_gibibytes = 93
    resource = {
      platform = "cpu-d3"
      preset   = "32vcpu-128gb"
    }
    public_ip = false
  }

  validation {
    condition = (var.nfs.enabled
      ? (
        var.nfs.size_gibibytes % 93 == 0 &&
        var.nfs.size_gibibytes <= 262074
      )
      : true
    )
    error_message = "NFS size must be a multiple of 93 GiB and maximum value is 262074 GiB"
  }
}
resource "terraform_data" "check_nfs" {
  depends_on = [
    terraform_data.check_region,
  ]

  lifecycle {
    precondition {
      condition = (var.nfs.enabled
        ? contains(module.resources.platforms, var.nfs.resource.platform)
        : true
      )
      error_message = "Unsupported platform '${var.nfs.resource.platform}'."
    }

    precondition {
      condition = (var.nfs.enabled
        ? contains(keys(module.resources.by_platform[var.nfs.resource.platform]), var.nfs.resource.preset)
        : true
      )
      error_message = "Unsupported preset '${var.nfs.resource.preset}' for platform '${var.nfs.resource.platform}'."
    }

    precondition {
      condition = (var.nfs.enabled
        ? contains(module.resources.platform_regions[var.nfs.resource.platform], var.region)
        : true
      )
      error_message = "Unsupported platform '${var.nfs.resource.platform}' in region '${var.region}'. See https://docs.nebius.com/compute/virtual-machines/types"
    }
  }
}

variable "nfs_in_k8s" {
  type = object({
    enabled         = bool
    version         = optional(string)
    use_stable_repo = optional(bool, true)
    size_gibibytes  = optional(number)
    disk_type       = optional(string)
    filesystem_type = optional(string)
    threads         = optional(number)
  })
  default = {
    enabled = false
  }
  validation {
    condition = (
      !var.nfs_in_k8s.enabled
      ||
      (
        var.nfs_in_k8s.filesystem_type != null
        && var.nfs_in_k8s.disk_type != null
        && var.nfs_in_k8s.size_gibibytes != null
        && (
          !contains(["NETWORK_SSD_IO_M3", "NETWORK_SSD_NON_REPLICATED"], var.nfs_in_k8s.disk_type)
          || (var.nfs_in_k8s.size_gibibytes % 93 == 0)
        )
      )
    )

    error_message = <<EOT
If NFS in K8s is enabled, filesystem_type, disk_type, and size_gibibytes must be set.
Additionally, if disk_type is NETWORK_SSD_IO_M3 or NETWORK_SSD_NON_REPLICATED, size_gibibytes must be a multiple of 93.
EOT
  }
}

# endregion nfs-server

# region k8s

variable "k8s_version" {
  description = "Version of the k8s to be used."
  type        = string
  default     = null

  validation {
    condition     = var.k8s_version == null || can(regex("^[\\d]+\\.[\\d]+$", var.k8s_version))
    error_message = "The k8s cluster version must be null or in format `<MAJOR>.<MINOR>`."
  }
}

variable "platform_cuda_versions" {
  description = "Per-platform CUDA versions consumed by Slurm/operator (e.g., 12.8.2). Keys are platform IDs (e.g., gpu-h100-sxm)."
  type        = map(string)
  default = {
    cpu-e2         = "12.9.0"
    cpu-d3         = "12.9.0"
    gpu-h100-sxm   = "12.9.0"
    gpu-h200-sxm   = "12.9.0"
    gpu-b200-sxm   = "12.9.0"
    gpu-b200-sxm-a = "12.9.0"
    gpu-b300-sxm   = "13.0.2"
  }
}

variable "platform_driver_presets" {
  description = "Per-platform GPU driver presets. Keys are platform IDs (e.g., gpu-h100-sxm); values are driver presets (e.g., cuda13.0)."
  type        = map(string)
  default = {
    cpu-e2         = "cuda12.8"
    cpu-d3         = "cuda12.8"
    gpu-h100-sxm   = "cuda12.8"
    gpu-h200-sxm   = "cuda12.8"
    gpu-b200-sxm   = "cuda12.8"
    gpu-b200-sxm-a = "cuda12.8"
    gpu-b300-sxm   = "cuda13.0"
  }
}

variable "use_preinstalled_gpu_drivers" {
  description = "Enable preinstalled mode for worker nodes."
  type        = bool
  default     = false
}

variable "nvidia_admin_conf_lines" {
  description = "Lines to write to /etc/modprobe.d/nvidia_admin.conf via cloud-init (GPU workers only)."
  type        = list(string)
  default     = []
}

variable "k8s_cluster_node_ssh_access_users" {
  description = "SSH user credentials for accessing k8s nodes."
  type = list(object({
    name        = string
    public_keys = list(string)
  }))
  nullable = false
  default  = []
}

variable "etcd_cluster_size" {
  description = "Size of the etcd cluster."
  type        = number
  default     = 3
}

# endregion k8s

# endregion Infrastructure

# region Slurm

variable "slurm_operator_version" {
  description = "Version of soperator."
  type        = string
  nullable    = false
}

variable "slurm_operator_stable" {
  description = "Is the version of soperator stable."
  type        = bool
  default     = true
}

variable "slurm_nodesets_enabled" {
  description = "Enable nodesets feature for Slurm cluster. When enabled, creates separate nodesets for each worker configuration."
  type        = bool
  default     = false
}

variable "slurm_nodesets_partitions" {
  description = <<-EOT
    Partition configuration for nodesets. Used only when slurm_nodesets_enabled is true.
    Users must not remove the "hidden" partition.
    Users can modify the "main" partition, but should not remove it (there must be at least one default partition).
  EOT
  type = list(object({
    name         = string
    is_all       = optional(bool, false)
    nodeset_refs = optional(list(string), [])
    config       = string
  }))
  default = []

  validation {
    condition = length(setsubtract(
      toset(flatten([
        for p in var.slurm_nodesets_partitions : coalesce(p.nodeset_refs, [])
      ])),
      toset([for w in var.slurm_nodeset_workers : w.name])
    )) == 0

    error_message = "All slurm_nodesets_partitions[].nodeset_refs must reference existing slurm_nodeset_workers[].name values."
  }
}

# region PartitionConfiguration

variable "slurm_partition_config_type" {
  description = "Type of the Slurm partition config. Could be either `default` or `custom`."
  default     = "default"
  type        = string

  validation {
    condition     = (contains(["default", "custom"], var.slurm_partition_config_type))
    error_message = "Invalid partition config type. It must be one of `default` or `custom`."
  }
}

variable "slurm_partition_raw_config" {
  description = "Partition config in case of `custom` slurm_partition_config_type. Each string must be started with `PartitionName`."
  default     = []
  type        = list(string)
}

# endregion PartitionConfiguration

# region WorkerFeatures

variable "slurm_worker_features" {
  description = "List of features to be enabled on worker nodes."
  type = list(object({
    name          = string
    hostlist_expr = string
    nodeset_name  = optional(string)
  }))
  default = []
}

# endregion WorkerFeatures

# region HealthCheckConfig

variable "slurm_health_check_config" {
  description = "Health check configuration."
  type = object({
    health_check_interval = number
    health_check_program  = string
    health_check_node_state = list(object({
      state = string
    }))
  })
  nullable = true
  default  = null
}

# endregion HealthCheckConfig

# region Nodes

variable "slurm_nodeset_system" {
  description = "Configuration of System node set for system resources created by Soperator."
  type = object({
    min_size = number
    max_size = number
    resource = object({
      platform = string
      preset   = string
    })
    boot_disk = object({
      type                 = string
      size_gibibytes       = number
      block_size_kibibytes = number
    })
  })
  nullable = false
  default = {
    min_size = 3
    max_size = 9
    resource = {
      platform = "cpu-d3"
      preset   = "16vcpu-64gb"
    }
    boot_disk = {
      type                 = "NETWORK_SSD"
      size_gibibytes       = 128
      block_size_kibibytes = 4
    }
  }
  validation {
    condition     = var.slurm_nodeset_system.boot_disk.size_gibibytes >= 128
    error_message = "Boot disks for system nodes must be at least 128 GiB."
  }
  validation {
    condition     = var.slurm_nodeset_system.min_size >= 3
    error_message = "Minimum size of the system node group must be at least 3."
  }
}

variable "slurm_nodeset_controller" {
  description = "Configuration of Slurm Controller node set. Only a single controller node is supported."
  type = object({
    size = number
    resource = object({
      platform = string
      preset   = string
    })
    boot_disk = object({
      type                 = string
      size_gibibytes       = number
      block_size_kibibytes = number
    })
  })
  nullable = false
  default = {
    size = 1
    resource = {
      platform = "cpu-d3"
      preset   = "16vcpu-64gb"
    }
    boot_disk = {
      type                 = "NETWORK_SSD"
      size_gibibytes       = 128
      block_size_kibibytes = 4
    }
  }
  validation {
    condition     = var.slurm_nodeset_controller.boot_disk.size_gibibytes >= 128
    error_message = "Boot disks for controller nodes must be at least 128 GiB."
  }
  validation {
    condition     = var.slurm_nodeset_controller.size == 1
    error_message = "Size of the controller node group must be exactly 1."
  }
}

variable "slurm_nodeset_workers" {
  description = "Configuration of Slurm Worker node sets."
  type = list(object({
    name = string
    size = number
    autoscaling = optional(object({
      enabled  = optional(bool, true)
      min_size = optional(number)
    }), {})
    resource = object({
      platform = string
      preset   = string
    })
    boot_disk = object({
      type                 = string
      size_gibibytes       = number
      block_size_kibibytes = number
    })
    gpu_cluster = optional(object({
      infiniband_fabric = string
    }))
    preemptible = optional(object({}))
    reservation_policy = optional(object({
      policy          = optional(string)
      reservation_ids = optional(list(string))
    }))
    features         = optional(list(string))
    create_partition = optional(bool)
  }))
  nullable = false
  default = [{
    name = "worker"
    size = 1
    resource = {
      platform = "cpu-d3"
      preset   = "16vcpu-64gb"
    }
    boot_disk = {
      type                 = "NETWORK_SSD"
      size_gibibytes       = 512
      block_size_kibibytes = 4
    }
  }]

  validation {
    condition = alltrue([
      for worker in var.slurm_nodeset_workers :
      (worker.size > 0)
    ])
    error_message = "Worker nodeset size must be greater than 0."
  }

  validation {
    condition     = length(var.slurm_nodeset_workers) > 0
    error_message = "At least one worker nodeset must be provided."
  }

  validation {
    condition     = length(distinct([for worker in var.slurm_nodeset_workers : worker.name])) == length(var.slurm_nodeset_workers)
    error_message = "All worker nodeset names must be unique."
  }

  validation {
    condition = alltrue([
      for worker in var.slurm_nodeset_workers :
      (worker.boot_disk.size_gibibytes >= 512)
    ])
    error_message = "Boot disks for worker nodes must be at least 512 GiB."
  }

  validation {
    condition = alltrue([
      for worker in var.slurm_nodeset_workers :
      worker.autoscaling.min_size == null || worker.autoscaling.min_size <= worker.size
    ])
    error_message = "Worker nodeset autoscaling.min_size must be less than or equal to size."
  }
}

variable "slurm_nodeset_login" {
  description = "Configuration of Slurm Login node set."
  type = object({
    size = number
    resource = object({
      platform = string
      preset   = string
    })
    boot_disk = object({
      type                 = string
      size_gibibytes       = number
      block_size_kibibytes = number
    })
  })
  nullable = false
  default = {
    size = 1
    resource = {
      platform = "cpu-d3"
      preset   = "16vcpu-64gb"
    }
    boot_disk = {
      type                 = "NETWORK_SSD"
      size_gibibytes       = 256
      block_size_kibibytes = 4
    }
  }
  validation {
    condition     = var.slurm_nodeset_login.boot_disk.size_gibibytes >= 256
    error_message = "Boot disks for login nodes must be at least 256 GiB."
  }
  validation {
    condition     = var.slurm_nodeset_login.size >= 1
    error_message = "Size of the login node group must be at least 1."
  }
}

variable "slurm_nodeset_accounting" {
  description = "Configuration of Slurm Accounting node set."
  type = object({
    resource = object({
      platform = string
      preset   = string
    })
    boot_disk = object({
      type                 = string
      size_gibibytes       = number
      block_size_kibibytes = number
    })
  })
  default = {
    resource = {
      platform = "cpu-d3"
      preset   = "8vcpu-32gb"
    }
    boot_disk = {
      type                 = "NETWORK_SSD"
      size_gibibytes       = 128
      block_size_kibibytes = 4
    }
  }
  validation {
    condition     = var.slurm_nodeset_accounting.boot_disk.size_gibibytes >= 128
    error_message = "Boot disks for accounting nodes must be at least 128 GiB."
  }
}

resource "terraform_data" "check_slurm_nodeset_accounting" {
  lifecycle {
    precondition {
      condition = (var.accounting_enabled
        ? var.slurm_nodeset_accounting != null
        : true
      )
      error_message = "Accounting node set must be provided when accounting is enabled."
    }
  }
}

variable "slurm_nodeset_nfs" {
  description = "Configuration of NFS node set."
  type = object({
    size = number
    resource = object({
      platform = string
      preset   = string
    })
    boot_disk = object({
      type                 = string
      size_gibibytes       = number
      block_size_kibibytes = number
    })
  })
  nullable = true
  default  = null
  validation {
    condition     = var.slurm_nodeset_nfs == null || var.slurm_nodeset_nfs.boot_disk.size_gibibytes >= 128
    error_message = "Boot disks for NFS nodes must be at least 128 GiB."
  }
  validation {
    condition     = var.slurm_nodeset_nfs == null || var.slurm_nodeset_nfs.size == 1
    error_message = "Size of the NFS node group must be exactly 1."
  }
}

resource "terraform_data" "check_slurm_nodeset" {
  for_each = merge({
    "system"     = var.slurm_nodeset_system
    "controller" = var.slurm_nodeset_controller
    "login"      = var.slurm_nodeset_login
    }, { for i, worker in var.slurm_nodeset_workers :
    "worker_${i}" => worker
    },
    var.slurm_nodeset_nfs != null ? {
      "nfs" = var.slurm_nodeset_nfs
    } : {}
  )

  depends_on = [
    terraform_data.check_region,
  ]

  lifecycle {
    precondition {
      condition = (
        try(each.value.size, 0) > 0 ||
        try(each.value.min_size, 0) > 0
      )
      error_message = "Either size or min_size must be greater than zero in node set ${each.key}."
    }

    precondition {
      condition     = contains(module.resources.platforms, each.value.resource.platform)
      error_message = "Unsupported platform '${each.value.resource.platform}' in node set '${each.key}'."
    }

    precondition {
      condition     = contains(keys(module.resources.by_platform[each.value.resource.platform]), each.value.resource.preset)
      error_message = "Unsupported preset '${each.value.resource.preset}' for platform '${each.value.resource.platform}' in node set '${each.key}'."
    }

    precondition {
      condition     = contains(module.resources.platform_regions[each.value.resource.platform], var.region)
      error_message = "Unsupported platform '${each.value.resource.platform}' in region '${var.region}'. See https://docs.nebius.com/compute/virtual-machines/types"
    }

    # TODO: precondition for total node group count
  }
}

# region Worker

variable "slurm_worker_sshd_config_map_ref_name" {
  description = "Name of configmap with SSHD config, which runs in slurmd container."
  type        = string
  default     = ""
}

# endregion Worker

# region Login

variable "slurm_login_sshd_config_map_ref_name" {
  description = "Name of configmap with SSHD config, which runs in slurmd container."
  type        = string
  default     = ""
}

variable "slurm_login_ssh_root_public_keys" {
  description = "Authorized keys accepted for connecting to Slurm login nodes via SSH as 'root' user."
  type        = list(string)
  nullable    = false

  validation {
    condition     = length(var.slurm_login_ssh_root_public_keys) >= 1
    error_message = "At least one SSH public key must be provided."
  }

  validation {
    condition     = alltrue([for k in var.slurm_login_ssh_root_public_keys : length(k) > 0])
    error_message = "SSH public keys must not be empty strings."
  }
}

# endregion Login

# region Exporter

variable "slurm_exporter_enabled" {
  description = "Whether to enable Slurm metrics exporter."
  type        = bool
  default     = true
}

# endregion Exporter

# region REST API

variable "slurm_rest_enabled" {
  description = "Whether to enable Slurm REST API."
  type        = bool
  default     = true
}

# endregion REST API

# endregion Nodes

# region Config

variable "slurm_shared_memory_size_gibibytes" {
  description = "Shared memory size for Slurm controller and worker nodes in GiB."
  type        = number
  default     = 64
}

# endregion Config

# region Telemetry

variable "telemetry_enabled" {
  description = "Whether to enable telemetry."
  type        = bool
  default     = true
}

variable "public_o11y_enabled" {
  description = "Whether to enable public observability endpoints."
  type        = bool
  default     = true
}

variable "dcgm_job_mapping_enabled" {
  description = "Whether to enable HPC job mapping by installing a separate dcgm-exporter"
  type        = bool
  default     = true
}

variable "soperator_notifier" {
  description = "Configuration of the Soperator Notifier (https://github.com/nebius/soperator/tree/main/helm/soperator-notifier)."
  type = object({
    enabled           = bool
    slack_webhook_url = optional(string)
  })
  default = {
    enabled = false
  }
  nullable = false

  validation {
    condition = (
      var.soperator_notifier.enabled
      ? coalesce(var.soperator_notifier.slack_webhook_url, "not_provided") != "not_provided"
      : true
    )
    error_message = "Slack webhook URL must be provided if Soperator Notifier is enabled."
  }
}

# endregion Telemetry

# region Accounting

variable "accounting_enabled" {
  description = "Whether to enable accounting."
  type        = bool
  default     = false
}

variable "slurmdbd_config" {
  description = "Slurmdbd.conf configuration. See https://slurm.schedmd.com/slurmdbd.conf.html.Not all options are supported."
  type        = map(any)
  default = {
    # archiveEvents : "yes"
    # archiveJobs : "yes"
    # archiveSteps : "yes"
    # archiveSuspend : "yes"
    # archiveResv : "yes"
    # archiveUsage : "yes"
    # archiveTXN : "yes"
    # debugLevel : "info"
    # tcpTimeout : 120
    # purgeEventAfter : "1month"
    # purgeJobAfter : "1month"
    # purgeStepAfter : "1month"
    # purgeSuspendAfter : "12month"
    # purgeResvAfter : "1month"
    # purgeUsageAfter : "1month"
    # debugFlags : "DB_ARCHIVE"
  }
}

variable "slurm_accounting_config" {
  description = "Slurm.conf accounting configuration. See https://slurm.schedmd.com/slurm.conf.html. Not all options are supported."
  type        = map(any)
  default = {
    # accountingStorageTRES: "gres/gpu,license/iop1"
    # accountingStoreFlags: "job_comment,job_env,job_extra,job_script,no_stdio"
    # acctGatherInterconnectType: "acct_gather_interconnect/ofed"
    # acctGatherFilesystemType: "acct_gather_filesystem/lustre"
    # jobAcctGatherType: "jobacct_gather/cgroup"
    # jobAcctGatherFrequency: 30
    # priorityWeightAge: 1
    # priorityWeightFairshare: 1
    # priorityWeightQOS: 1
    # priorityWeightTRES: 1
  }
}

# endregion Accounting

# region Backups

variable "backups_enabled" {
  description = "Whether to enable jail backups. Choose from 'auto', 'force_enable' and 'force_disable'. 'auto' enables backups for jails with max size < 12 TB."
  type        = string
  default     = "auto"

  validation {
    condition     = contains(["auto", "force_enable", "force_disable"], var.backups_enabled)
    error_message = "Valid values for backups_enabled are 'auto', 'force_enable' and 'force_disable'"
  }
}

variable "backups_password" {
  description = "Password for encrypting jail backups."
  type        = string
  nullable    = false
  sensitive   = true
}

variable "backups_schedule" {
  description = "Cron schedule for backup task."
  type        = string
  nullable    = false
}

variable "backups_prune_schedule" {
  description = "Cron schedule for prune task."
  type        = string
  nullable    = false
}

variable "backups_retention" {
  description = "Backups retention policy."
  type        = map(any)
}

variable "cleanup_bucket_on_destroy" {
  description = "Whether to delete on destroy all backup data from bucket or not"
  type        = bool
}

# endregion Backups

# region Apparmor
variable "use_default_apparmor_profile" {
  description = "Whether to use default AppArmor profile."
  type        = bool
  default     = true
}

# endregion Apparmor

# region Maintenance
variable "maintenance" {
  description = "Whether to enable maintenance mode."
  type        = string
  default     = "none"

  validation {
    condition     = contains(["downscaleAndDeletePopulateJail", "downscaleAndOverwritePopulateJail", "downscale", "none", "skipPopulateJail"], var.maintenance)
    error_message = "The maintenance variable must be one of: downscaleAndDeletePopulateJail, downscaleAndOverwritePopulateJail, downscale, none, skipPopulateJail."
  }
}

variable "maintenance_ignore_node_groups" {
  description = "List of node groups that Soperator should ignore for maintenance events. Supported values: controller, nfs, system, login, accounting."
  type        = list(string)
  default     = ["controller", "nfs"]
}

# endregion Maintenance

# endregion Slurm

# region ActiveChecks
variable "active_checks_scope" {
  type        = string
  description = "Scope of active checks. Defines what active checks should be checked during cluster bootstrap."
  default     = ""
  validation {
    condition     = contains(["dev", "testing", "prod_quick", "prod_acceptance"], var.active_checks_scope)
    error_message = "active_checks_scope should be one of: dev, testing, prod_quick, prod_acceptance."
  }
}

# endregion ActiveChecks
